# Jignesh Health Companion — Standalone App

A real, independent website — not a Claude artifact. Installed on Jignesh's phone, it
opens as its own app icon with its own screen, no browser chrome, and no connection to
your Claude account. It calls Claude for the smart features (food check on unlisted
dishes, the Ask panel) through your own backend, not through claude.ai.

**Live URL:** https://health-tracker-preeti13.vercel.app

---

## What's in this folder
| File | Purpose |
|---|---|
| `index.html` | The whole app — React + Babel loaded from a CDN, no build step |
| `manifest.json` | Makes the site installable as a home-screen app |
| `sw.js` | Service worker — caches the app shell for offline use |
| `icons/icon-192.png`, `icons/icon-512.png` | Home-screen app icons |
| `api/chat.js` | Backend function holding your Anthropic API key, proxies requests to Claude |

---

## One-time setup (already done — for reference / redoing on a new project)

1. **GitHub account** (github.com) — holds the files.
2. **Vercel account** (vercel.com) — sign in with GitHub, import the repo, deploy.
3. **Anthropic API key** (console.anthropic.com → Settings → API Keys) — separate,
   paid, billed per request. Small cost for one person's daily use, but not free —
   needs a payment method on the Anthropic console.
4. In Vercel → **Settings → Environment Variables** → add `ANTHROPIC_API_KEY` with
   the real key → redeploy so it takes effect.
5. In Vercel → **Settings → Deployment Protection** → set to **Disabled**. This is
   required — Vercel's default "Vercel Authentication" wraps the site in an SSO login
   wall that breaks the app (blank page) and blocks the manifest from loading.

## Updating the app later

1. Open the file you need to change in the GitHub repo (usually `index.html`).
2. Click the pencil icon → edit → paste in the new version → **Commit to main**.
3. Vercel auto-redeploys within about a minute. Check the **Deployments** tab for
   "Ready."
4. Test in an **incognito/private browser window** — regular windows cache
   aggressively and can show you the old broken version even after a fix is live.

## Installing on Jignesh's phone

1. Open **https://health-tracker-preeti13.vercel.app** in Safari (iPhone) or Chrome
   (Android) — a normal website, no claude.ai involved.
2. iPhone: Share icon → **Add to Home Screen**.
   Android: ⋮ menu → **Add to Home screen** (or "Install app" if offered).
3. It opens as its own standalone app from then on.

---

## Troubleshooting

**Blank cream-colored page, nothing loads.**
Almost always one of two things:
- **Deployment Protection is on.** Check Settings → Deployment Protection = Disabled.
- **You're on a preview URL, not production.** Any URL with `-git-` or a random hash
  in it (e.g. `health-tracker-git-main-preeti13.vercel.app`) is a preview alias and
  behaves differently. Always use the plain production URL above.

If it's still blank after both of those: open DevTools (F12) → Console tab, hard
refresh (Ctrl+Shift+R), and read the actual red error text — that tells you exactly
what broke, rather than guessing.

**Food Check / Ask panel show an error instead of a response.**
`ANTHROPIC_API_KEY` isn't set in Vercel, wasn't redeployed after being added, or the
Anthropic account is out of credit / has no payment method attached. Check Vercel →
Settings → Environment Variables, and console.anthropic.com billing.

**Home screen icon looks broken or missing.**
Re-upload the `icons/` folder — binary image files occasionally get corrupted when
dragged into GitHub's web upload UI. Re-drag both PNGs, commit, redeploy.

**Made a change and it's not showing up.**
You're almost certainly looking at a cached version. Incognito window + hard refresh
before concluding something's wrong.

---

## Data & privacy

Jignesh's daily logs (food, habits, supplements) live in his phone's own browser
storage — private to his device, not synced anywhere, not visible to you unless he
shows you directly. If you later want shared visibility (e.g. checking his adherence
remotely), that needs a real backend database instead of local storage — a separate
build, not a small tweak. Say the word if you want that next.
